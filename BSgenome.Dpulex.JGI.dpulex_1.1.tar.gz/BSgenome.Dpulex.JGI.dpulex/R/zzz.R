###
###

.pkgname <- "BSgenome.Dpulex.JGI.dpulex"

.seqnames <- names(fasta.info("/home/rtraborn/R/x86_64-redhat-linux-gnu-library/3.1/BSgenome/extdata/dpulex.fa"))

.circ_seqs <- NULL

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Daphnia pulex",
        species="Waterflea",
        provider="JGI",
        provider_version="dpulex",
        release_date="April. 2011",
        release_name="Daphnia Genomics Consortium Daphnia pulex assembly v1.1",
        source_url="NA",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "dpulex"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

